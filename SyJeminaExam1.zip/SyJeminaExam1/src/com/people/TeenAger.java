//Answer 1
package com.people;

public class TeenAger {
	//Answer 2
	private String name;
	private int age;
	
	//Answer 3
	public TeenAger() {
		System.out.println("Teenager was created...");
	}
	//Answer 4
	public TeenAger(String name, int age) {
		this.name = name;
		this.age = age;
	}
	//Answer 5
	public void setName(String personName) {
		this.name = personName;
	}
	//Answer 6
	public void setAge(int personAge) {
		this.age = personAge;
	}
	//Answer 7
	public String getName() {
		return this.name;
	}
	//Answer 8
	public int getAge() {
		return this.age;
	}
	//Answer 9
	public void dance(String danceName) {
		System.out.println(name + " knows how to dance " + danceName);
	}
	//Answer 10
	public void dance (int dancenumber) {
		System.out.println(name + " knows how to dance " + dancenumber + " dances" );
	}
	
}
