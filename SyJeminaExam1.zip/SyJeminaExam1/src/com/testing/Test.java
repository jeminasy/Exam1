//Answer 11
package com.testing;

import com.people.TeenAger;;

public class Test {
	public static void main(String[] args) {
		//Answer 12
		TeenAger teen1 = new TeenAger();
		//Answer 13
		teen1.setName("Jemina");
		teen1.setAge(18);
		System.out.println(teen1.getName());
		System.out.println(teen1.getAge());
		teen1.dance("Ballet");
		teen1.dance(6);
		
		System.out.println();
		//Answer 14
		TeenAger teen2 = new TeenAger("Sy", 18);
		//Answer 15
		System.out.println(teen2.getName());
		System.out.println(teen2.getAge());
		teen2.dance("Waltz");
		teen2.dance(5);
	}
}
